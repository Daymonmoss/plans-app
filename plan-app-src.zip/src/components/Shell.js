import React from "react";
import {NotFound} from "./NotFound";
import {BrowserRouter, Route, Switch, withRouter} from "react-router-dom";

import {routes} from "../routes";
import {NavBar} from "./NavBar";
import {BottomNavBar} from "./BottomNavBar";


export class Shell extends React.Component {
	constructor(props) {
		super(props);
		this.store = props.AppStore;
	}

	render() {
		return (
			<BrowserRouter>
				<div className="container">
					<div className="row">
						<div className="col-12">
							<NavBar/>
							<Switch>
								{routes.map(({path, component}, key) => (
									<Route exact path={path} component={component} key={key}/>
								))}
								<Route exact component={NotFound}/>
							</Switch>
							<BottomNavBar/>
						</div>
					</div>
				</div>
			</BrowserRouter>
		)
	}




}
