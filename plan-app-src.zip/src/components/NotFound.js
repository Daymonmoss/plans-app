import React from 'react';

export const NotFound = () => <h2>Not found, sorry!</h2>