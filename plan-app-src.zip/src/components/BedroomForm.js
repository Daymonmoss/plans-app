import React from 'react';
import {inject, observer} from "mobx-react";
import {linkedControl} from "../foundation/utils";
import {Checkbox} from "./FormControls";


@inject('AppStore')
@observer
class BedroomForm extends React.Component {
	constructor(props) {
		super(props);
		this.store = props.AppStore.formData.bedroomItems;
	}

	render() {
		return (
			<form>
				<div className="form-row form-group">
					<div className="col-12">
						<h3 className={"mb-3"}>Предметы спальни</h3>
					</div>
					<div className="col-6">

						<Checkbox
							label={"Диван-кровать"}
							{...linkedControl(this.store, 'bedCoach', true)}
						/>

						<Checkbox
							label={"Кровать"}
							{...linkedControl(this.store, 'bed', true)}

						/>
						<Checkbox
							label={"Комод"}
							{...linkedControl(this.store, 'bureau', true)}
						/>
						<Checkbox
							label={"Телевизор"}
							{...linkedControl(this.store, 'tv', true)}
						/>
						<Checkbox
							label={"Туалетный столик"}
							{...linkedControl(this.store, 'dresser', true)}
						/>
						<Checkbox
							label={"Прикроватные тумбочки"}
							{...linkedControl(this.store, 'bedsideTable', true)}
						/>

						<Checkbox
							label={"Компьютерный стол"}
							{...linkedControl(this.store, 'computerTable', true)}
						/>


					</div>
				</div>
			</form>)
	}
}

export {BedroomForm}