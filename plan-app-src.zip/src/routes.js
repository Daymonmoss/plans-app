import {MainForm} from "./components/MainForm";
import {LobbyForm} from "./components/LobbyForm";
import {BathroomForm} from "./components/BathroomForm";
import {KitchenForm} from "./components/KitchenForm";
import {LivingRoomForm} from "./components/LivingRoomForm";
import {BedroomForm} from "./components/BedroomForm";
import {NotFound} from "./components/NotFound";

import StartIcon from './assets/freepik-icons/011-notes.svg';
import LobbyIcon from './assets/freepik-icons/008-room-key.svg';
import BathroomIcon from './assets/freepik-icons/004-bathtub.svg';
import KitchenIcon from './assets/freepik-icons/009-cutlery.svg';
import LivingRoomIcon from './assets/freepik-icons/006-sofa.svg';
import BedroomIcon from './assets/freepik-icons/001-bed.svg';
import ResultIcon from './assets/freepik-icons/012-photo-camera.svg'



export const routes = [
	{path: '/', component: MainForm, label:'Старт', icon: StartIcon},
	{path: '/lobby', component: LobbyForm, label:'Прихожая', icon: LobbyIcon},
	{path: '/bathroom', component: BathroomForm,label:'Санузел', icon: BathroomIcon},
	{path: '/kitchen', component: KitchenForm,label:'Кухня', icon:KitchenIcon},
	{path: '/livingroom', component: LivingRoomForm,label:'Гостиная', icon: LivingRoomIcon},
	{path: '/bedroom', component: BedroomForm,label:'Спальня', icon: BedroomIcon},
	{path: '/result', component: NotFound,label:'Ваша планировка', icon: ResultIcon},
];