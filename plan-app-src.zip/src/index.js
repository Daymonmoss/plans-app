import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/css/bootstrap-grid.css"
import "./style.css";

import React from "react";
import ReactDOM from "react-dom";
import {AppStore} from './store';
import {Provider} from "mobx-react";
import {Shell} from "./components/Shell";

const App  = () => <Provider AppStore={AppStore}><Shell/></Provider>

const rootElement = document.getElementById("root");
ReactDOM.render(<App/>, rootElement);
