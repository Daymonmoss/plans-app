import {observable, autorun, toJS, action, set} from "mobx";
import defaultState from './defaultState';
import {AppConfig} from "../config";


class Store {
	@observable formData;

	@action restore() {
		let state = localStorage.getItem('APP_TEST');
		set(this.formData, JSON.parse(state))
	}

	@action toDefaultState(){
		this.formData = defaultState;
	}

	constructor(props) {
		this.toDefaultState();
		if(AppConfig.spoolStore) this.restore();
	}

}

let AppStore = new Store();

if(AppConfig.spoolStore){
	autorun(()=>{
		localStorage.setItem('APP_TEST', JSON.stringify(toJS(AppStore.formData)));
	})
}




export {AppStore};
