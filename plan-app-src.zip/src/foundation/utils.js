
/**
 * Binds EventTarget to object in two-way fashion
 * @example <input {...linkedObject(object, 'customerName')}/>
 * @param object object to link to and from
 * @param name key in object to bind to
 * @return {{onInput: (function(*): *), onChange: onChange, value: *}}
 */
export const linkedControl = (object, name, checkable, onHandle) => {

	const handler = event => {

		if(event.target.type === 'radio'){

			let siblings = document.querySelectorAll(`input[name="${event.target.name}"]`);

			siblings.forEach( radio => {
				radio.dispatchEvent(new Event('change'));
			})
			object[name] = !!event.target.checked;
		}else if(event.target.type==='checkbox'){
			object[name] = !!event.target.checked
		}else{
			object[name] = event.target.value
		}

		!!onHandle && onHandle(event);
	};
	let linker;

	if(checkable) {

		linker = {
			onChange: handler,
			checked: object[name],
		}
	}else{
		linker = {
			onInput: handler,
			onChange:handler,
			value: object[name],

		}
	}

	return linker;
}