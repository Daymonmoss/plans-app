const AppConfig = {
	spoolStore: true,
}

export {AppConfig}